import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyDMREnjMYCAF2vCszfITm19r-448ZeBIwA",
  authDomain: "cleansightai-ea9f5.firebaseapp.com",
  databaseURL: "https://cleansightai-ea9f5-default-rtdb.firebaseio.com",
  projectId: "cleansightai-ea9f5",
  storageBucket: "cleansightai-ea9f5.firebasestorage.app",
  messagingSenderId: "801802746000",
  appId: "1:801802746000:web:c74e0b327cade03a118015",
  measurementId: "G-ZN761ENNWE"
};

export const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
