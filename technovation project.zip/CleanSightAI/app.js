import { db } from "./firebase.js";
import { ref, push, onValue } from
"https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

const user = localStorage.getItem("user");
const role = localStorage.getItem("role");

if (!user) location.href = "index.html";
if (role !== "user") location.href = "admin.html";

// ================= RECYCLE LOGIC =================
const recyclableItems = [
  "plastic","bottle","paper","cardboard",
  "can","metal","glass","newspaper"
];

function getRecycleStatus(label) {
  label = label.toLowerCase();
  for (let i of recyclableItems)
    if (label.includes(i)) return "Recyclable ♻️";
  return "Non-Recyclable ❌";
}

// ================= DOM READY =================
document.addEventListener("DOMContentLoaded", () => {

  let model, lat = null, lng = null, marker;

  const img = document.getElementById("img");
  const spinner = document.getElementById("spinner");
  const result = document.getElementById("result");
  const history = document.getElementById("history");

  window.logout = () => {
    localStorage.clear();
    location.href = "index.html";
  };

  mobilenet.load().then(m => model = m);

  // MAP
  const map = L.map("map").setView([20,78],5);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(map);

  navigator.geolocation.getCurrentPosition(
    pos => {
      lat = pos.coords.latitude;
      lng = pos.coords.longitude;
      map.setView([lat,lng],15);
      marker = L.marker([lat,lng]).addTo(map);
      locText.innerText = "Auto location detected";
    },
    () => locText.innerText = "Click or search location"
  );

  map.on("click", e => {
    lat = e.latlng.lat;
    lng = e.latlng.lng;
    if (marker) marker.remove();
    marker = L.marker([lat,lng]).addTo(map);
    locText.innerText = "Location selected";
  });

  searchBox.onkeydown = async e => {
    if (e.key !== "Enter") return;
    const r = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${searchBox.value}`
    );
    const d = await r.json();
    if (!d.length) return alert("Not found");
    lat = +d[0].lat;
    lng = +d[0].lon;
    map.setView([lat,lng],15);
    if (marker) marker.remove();
    marker = L.marker([lat,lng]).addTo(map);
    locText.innerText = d[0].display_name;
  };

  imageUpload.onchange = e => {
    const reader = new FileReader();
    reader.onload = () => img.src = reader.result;
    reader.readAsDataURL(e.target.files[0]);
  };

  img.onload = async () => {
    if (!model || lat === null) return alert("Select location first");

    spinner.style.display = "block";
    const preds = await model.classify(img);
    spinner.style.display = "none";

    const item = preds[0].className;
    const status = getRecycleStatus(item);

    result.innerHTML = `<b>${item}</b><br>${status}`;

    push(ref(db, "reports/" + user.replace(/\./g,"_")), {
      item, status, lat, lng,
      image: img.src,
      time: new Date().toLocaleString()
    });
  };

  onValue(ref(db, "reports/" + user.replace(/\./g,"_")), snap => {
    history.innerHTML = "";
    snap.forEach(s => {
      const d = s.val();
      history.innerHTML += `
        <div class="card">
          <img src="${d.image}">
          <b>${d.item}</b>
          <p>${d.status}</p>
        </div>`;
    });
  });

});
