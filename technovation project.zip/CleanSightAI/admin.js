import { db } from "./firebase.js";
import { ref, onValue } from
"https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

if (localStorage.getItem("role") !== "admin")
  location.href = "index.html";

onValue(ref(db,"reports"), snap => {
  adminData.innerHTML = "";
  snap.forEach(userSnap => {
    userSnap.forEach(r => {
      const d = r.val();
      adminData.innerHTML += `
        <div class="card">
          <img src="${d.image}">
          <b>${d.item}</b>
          <p>${d.status}</p>
        </div>`;
    });
  });
});
