import { db } from "./firebase.js";
import { ref, set, get } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

const emailEl = document.getElementById("email");
const passEl = document.getElementById("password");
const msg = document.getElementById("msg");

window.register = async () => {
  const email = emailEl.value.trim();
  const pass = passEl.value.trim();

  if (!email || pass.length < 6) {
    msg.innerText = "Invalid input";
    return;
  }

  const key = email.replace(/\./g, "_");
  const role = email === "admin@gmail.com" ? "admin" : "user";

  await set(ref(db, "users/" + key), { email, pass, role });

  localStorage.setItem("user", email);
  localStorage.setItem("role", role);

  location.href = role === "admin" ? "admin.html" : "app.html";
};

window.login = async () => {
  const email = emailEl.value.trim();
  const pass = passEl.value.trim();
  const key = email.replace(/\./g, "_");

  const snap = await get(ref(db, "users/" + key));

  if (!snap.exists() || snap.val().pass !== pass) {
    msg.innerText = "Wrong login";
    return;
  }

  localStorage.setItem("user", email);
  localStorage.setItem("role", snap.val().role);

  location.href = snap.val().role === "admin" ? "admin.html" : "app.html";
};
